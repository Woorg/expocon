'head': {
    defaults: {
        title: 'Main page',
    },
    // inner: {
    //     title: 'Inner page',
    //     useSocialMetaTags: false
    // },
    // university: {
    //     title: 'University page',
    //     useSocialMetaTags: false
    // }
},

'income': {
    title: 'ИСТОЧНИКИ ДОХОДА',
    text: 'зарабатывайте с игрой и не только',
    list: [

    ]
},

'levels': {
    title: '5 уровней ДОХОДА',
    text: 'Минимальный доход уровня - реальные деньги, которые вы зарабатываете в процессе игры'
},

__iconsData: {
    
        'menu-icon': {
            width: '24px',
            height: '18px'
        },
    
},

__pages: [{
                name: 'index',
                href: 'index.html'
             }]