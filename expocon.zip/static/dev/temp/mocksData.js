'head': {
    defaults: {
        title: 'Main page',
    },
    // inner: {
    //     title: 'Inner page',
    //     useSocialMetaTags: false
    // },
    // university: {
    //     title: 'University page',
    //     useSocialMetaTags: false
    // }
},

'income': {
    title: 'ИСТОЧНИКИ ДОХОДА',
    text: 'зарабатывайте с игрой и не только',
    list: [

    ]
},

'levels': {
    title: '5 уровней ДОХОДА',
    text: 'Минимальный доход уровня - реальные деньги, которые вы зарабатываете в процессе игры'
},

__iconsData: {
    
        'arrow': {
            width: '512px',
            height: '512px'
        },
    
        'menu-icon': {
            width: '24px',
            height: '18px'
        },
    
        'play-icon': {
            width: '512px',
            height: '512px'
        },
    
        'section-icon-1': {
            width: '512px',
            height: '512px'
        },
    
        'section-icon-2': {
            width: '496px',
            height: '496px'
        },
    
        'section-icon-3': {
            width: '511.5px',
            height: '511.5px'
        },
    
        'section-icon-4': {
            width: '389.981px',
            height: '389.981px'
        },
    
        'stat-icon-1': {
            width: '496px',
            height: '496px'
        },
    
        'stat-icon-2': {
            width: '201.387px',
            height: '201.387px'
        },
    
        'stat-icon-3': {
            width: '512px',
            height: '512px'
        },
    
        'stat-icon-4': {
            width: '480.1px',
            height: '480.1px'
        },
    
        'stat-icon-5': {
            width: '512px',
            height: '512px'
        },
    
},

__pages: [{
                name: 'buy-ticket',
                href: 'buy-ticket.html'
             },{
                name: 'enter',
                href: 'enter.html'
             },{
                name: 'index',
                href: 'index.html'
             }]