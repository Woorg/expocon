__iconsData: {
    
        'menu-icon': {
            width: '24px',
            height: '18px'
        },
    
}