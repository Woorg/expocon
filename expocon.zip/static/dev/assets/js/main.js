/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "./assets/js/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./markup/assets/js/main.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./markup/assets/js/main.js":
/*!**********************************!*\
  !*** ./markup/assets/js/main.js ***!
  \**********************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var svg4everybody__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! svg4everybody */ "./node_modules/svg4everybody/dist/svg4everybody.js");
/* harmony import */ var svg4everybody__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(svg4everybody__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _blocks_exhibition_exhibition__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../blocks/exhibition/exhibition */ "./markup/blocks/exhibition/exhibition.js");
/* harmony import */ var _blocks_exhibition_exhibition__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_blocks_exhibition_exhibition__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _blocks_about_about__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../blocks/about/about */ "./markup/blocks/about/about.js");
/* harmony import */ var _blocks_about_about__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_blocks_about_about__WEBPACK_IMPORTED_MODULE_2__);


 // import levelsSlider from '../../blocks/levels/levels';
// import paymentSlider from '../../blocks/payment/payment';
// import faq from '../../blocks/faq/faq';
// import $ from 'jquery';
// import slick from 'slick-carousel';

(function ($) {
  svg4everybody__WEBPACK_IMPORTED_MODULE_0___default()();
  let styles = ['padding: 2px 9px', 'background: #2948ff', 'color: #fff', 'display: inline-block', 'box-shadow: 0 -1px 0 rgba(255, 255, 255, 0.2) inset, 0 5px 3px -5px rgba(0, 0, 0, 0.5), 0 -13px 5px -10px rgba(255, 255, 255, 0.4) inset', 'line-height: 1.56', 'text-align: left', 'font-size: 16px', 'font-weight: 400'].join(';');
  console.log('%c developed by igor gorlov https://igrlv.ru', styles);
  /*
    Lazyload images
  */

  let lazyLoadInstance = new LazyLoad({
    elements_selector: '.lazy',
    // load_delay: 500,
    use_native: true
  });

  if (lazyLoadInstance) {
    lazyLoadInstance.update();
  }

  $(function () {
    let $hButton = $('.h-user__button');
    let $hList = $('.h-user__list');
    $hButton.on('click', function () {
      console.log('click');
      $hList.toggleClass('h-user__list_active');
    });
    $(document).on('click', function (e) {
      if (!$(e.target).closest('.h-user__button').length) {
        $hList.removeClass('h-user__list_active');
      }
    });
    $('.nav__button').on('click', function (e) {
      e.preventDefault();
      $('.header__nav').toggleClass('nav_active');
    });
    $(document).on('click', function (e) {
      if (!$(e.target).closest('.nav__button').length) {
        $('.header__nav').removeClass('nav_active');
      }
    });
    $('.catalog__category').on('click', function (e) {
      e.preventDefault();
      console.log(e);
      let offsetLeft = e.pageX;
      let offsetRight = $('.catalog__bottom').outerWidth() - e.pageX - 60;
      console.log(offsetLeft);
      console.log($('.catalog__bottom').outerWidth()); // $(this).prev().toggleClass('catalog__sub_active');

      $(this).toggleClass('catalog__category_active');
      $(this).siblings().removeClass('catalog__category_active');
      $(this).prev('.catalog__sub').toggleClass('catalog__sub_active');
      $(this).siblings().prev('.catalog__sub').removeClass('catalog__sub_active'); // $(this).find('.catalog__sub').css('left', (offsetLeft + 60) + 'px');
      // if( ($('.catalog__bottom').outerWidth() / 2) < 585 ) {
      //   $(this).find('.catalog__sub-triangle').css('right', + 'auto');
      //   $(this).find('.catalog__sub-triangle').css('left', (offsetLeft) + 'px');
      // } else {
      //   $(this).find('.catalog__sub').css('left', 'auto');
      //   $(this).find('.catalog__sub').css('right', (offsetRight) + 'px');
      // }
    }); // Sliders

    _blocks_exhibition_exhibition__WEBPACK_IMPORTED_MODULE_1___default()();
    _blocks_about_about__WEBPACK_IMPORTED_MODULE_2___default()();
  });
})(jQuery);

/***/ }),

/***/ "./markup/blocks/about/about.js":
/*!**************************************!*\
  !*** ./markup/blocks/about/about.js ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function aboutSlider() {
  let $aboutSlider = $('.about__slider');

  if ($aboutSlider.length > 0) {
    $aboutSlider.slick({
      slidesToScroll: 1,
      dots: false,
      mobileFirst: true,
      // infinite: false,
      loop: true,
      lazyLoad: 'ondemand',
      // fade: true,
      speed: 300,
      focusOnSelect: true,
      waitForAnimate: false,
      // arrows: false,
      // appendDots: $('.exhibition__dots'),
      prevArrow: '.about__nav-arrow_back',
      nextArrow: '.about__nav-arrow_next',
      responsive: [{
        breakpoint: 1,
        settings: {
          slidesToShow: 1
        }
      }, {
        breakpoint: 600,
        settings: {
          slidesToShow: 1
        }
      }]
    });
  }
};

/***/ }),

/***/ "./markup/blocks/exhibition/exhibition.js":
/*!************************************************!*\
  !*** ./markup/blocks/exhibition/exhibition.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function exhibitionSlider() {
  let $exhibitionSlider = $('.exhibition__slider');

  if ($exhibitionSlider.length > 0) {
    $exhibitionSlider.slick({
      slidesToScroll: 1,
      dots: true,
      mobileFirst: true,
      // infinite: false,
      loop: true,
      lazyLoad: 'ondemand',
      fade: true,
      speed: 300,
      focusOnSelect: true,
      waitForAnimate: false,
      // arrows: false,
      appendDots: $('.exhibition__dots'),
      prevArrow: '.exhibition__arrow_back',
      nextArrow: '.exhibition__arrow_next',
      responsive: [{
        breakpoint: 1,
        settings: {
          slidesToShow: 1
        }
      }, {
        breakpoint: 600,
        settings: {
          slidesToShow: 1
        }
      }]
    });
    $('.exhibition__thumbs').slick({
      slidesToShow: 4,
      slidesToScroll: 1,
      mobileFirst: true,
      adaptiveHeight: true,
      asNavFor: '.exhibition__slider',
      dots: false,
      arrows: false,
      // centerMode: true,
      focusOnSelect: true,
      responsive: [{
        breakpoint: 1,
        settings: {
          slidesToShow: 2
        }
      }, {
        breakpoint: 600,
        settings: {
          slidesToShow: 4
        }
      }]
    });
  }
};

/***/ }),

/***/ "./node_modules/svg4everybody/dist/svg4everybody.js":
/*!**********************************************************!*\
  !*** ./node_modules/svg4everybody/dist/svg4everybody.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!function(root, factory) {
     true ? // AMD. Register as an anonymous module unless amdModuleId is set
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = (function() {
        return root.svg4everybody = factory();
    }).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)) : undefined;
}(this, function() {
    /*! svg4everybody v2.1.9 | github.com/jonathantneal/svg4everybody */
    function embed(parent, svg, target) {
        // if the target exists
        if (target) {
            // create a document fragment to hold the contents of the target
            var fragment = document.createDocumentFragment(), viewBox = !svg.hasAttribute("viewBox") && target.getAttribute("viewBox");
            // conditionally set the viewBox on the svg
            viewBox && svg.setAttribute("viewBox", viewBox);
            // copy the contents of the clone into the fragment
            for (// clone the target
            var clone = target.cloneNode(!0); clone.childNodes.length; ) {
                fragment.appendChild(clone.firstChild);
            }
            // append the fragment into the svg
            parent.appendChild(fragment);
        }
    }
    function loadreadystatechange(xhr) {
        // listen to changes in the request
        xhr.onreadystatechange = function() {
            // if the request is ready
            if (4 === xhr.readyState) {
                // get the cached html document
                var cachedDocument = xhr._cachedDocument;
                // ensure the cached html document based on the xhr response
                cachedDocument || (cachedDocument = xhr._cachedDocument = document.implementation.createHTMLDocument(""), 
                cachedDocument.body.innerHTML = xhr.responseText, xhr._cachedTarget = {}), // clear the xhr embeds list and embed each item
                xhr._embeds.splice(0).map(function(item) {
                    // get the cached target
                    var target = xhr._cachedTarget[item.id];
                    // ensure the cached target
                    target || (target = xhr._cachedTarget[item.id] = cachedDocument.getElementById(item.id)), 
                    // embed the target into the svg
                    embed(item.parent, item.svg, target);
                });
            }
        }, // test the ready state change immediately
        xhr.onreadystatechange();
    }
    function svg4everybody(rawopts) {
        function oninterval() {
            // while the index exists in the live <use> collection
            for (// get the cached <use> index
            var index = 0; index < uses.length; ) {
                // get the current <use>
                var use = uses[index], parent = use.parentNode, svg = getSVGAncestor(parent), src = use.getAttribute("xlink:href") || use.getAttribute("href");
                if (!src && opts.attributeName && (src = use.getAttribute(opts.attributeName)), 
                svg && src) {
                    if (polyfill) {
                        if (!opts.validate || opts.validate(src, svg, use)) {
                            // remove the <use> element
                            parent.removeChild(use);
                            // parse the src and get the url and id
                            var srcSplit = src.split("#"), url = srcSplit.shift(), id = srcSplit.join("#");
                            // if the link is external
                            if (url.length) {
                                // get the cached xhr request
                                var xhr = requests[url];
                                // ensure the xhr request exists
                                xhr || (xhr = requests[url] = new XMLHttpRequest(), xhr.open("GET", url), xhr.send(), 
                                xhr._embeds = []), // add the svg and id as an item to the xhr embeds list
                                xhr._embeds.push({
                                    parent: parent,
                                    svg: svg,
                                    id: id
                                }), // prepare the xhr ready state change event
                                loadreadystatechange(xhr);
                            } else {
                                // embed the local id into the svg
                                embed(parent, svg, document.getElementById(id));
                            }
                        } else {
                            // increase the index when the previous value was not "valid"
                            ++index, ++numberOfSvgUseElementsToBypass;
                        }
                    }
                } else {
                    // increase the index when the previous value was not "valid"
                    ++index;
                }
            }
            // continue the interval
            (!uses.length || uses.length - numberOfSvgUseElementsToBypass > 0) && requestAnimationFrame(oninterval, 67);
        }
        var polyfill, opts = Object(rawopts), newerIEUA = /\bTrident\/[567]\b|\bMSIE (?:9|10)\.0\b/, webkitUA = /\bAppleWebKit\/(\d+)\b/, olderEdgeUA = /\bEdge\/12\.(\d+)\b/, edgeUA = /\bEdge\/.(\d+)\b/, inIframe = window.top !== window.self;
        polyfill = "polyfill" in opts ? opts.polyfill : newerIEUA.test(navigator.userAgent) || (navigator.userAgent.match(olderEdgeUA) || [])[1] < 10547 || (navigator.userAgent.match(webkitUA) || [])[1] < 537 || edgeUA.test(navigator.userAgent) && inIframe;
        // create xhr requests object
        var requests = {}, requestAnimationFrame = window.requestAnimationFrame || setTimeout, uses = document.getElementsByTagName("use"), numberOfSvgUseElementsToBypass = 0;
        // conditionally start the interval if the polyfill is active
        polyfill && oninterval();
    }
    function getSVGAncestor(node) {
        for (var svg = node; "svg" !== svg.nodeName.toLowerCase() && (svg = svg.parentNode); ) {}
        return svg;
    }
    return svg4everybody;
});

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vbWFya3VwL2Fzc2V0cy9qcy9tYWluLmpzIiwid2VicGFjazovLy8uL21hcmt1cC9ibG9ja3MvYWJvdXQvYWJvdXQuanMiLCJ3ZWJwYWNrOi8vLy4vbWFya3VwL2Jsb2Nrcy9leGhpYml0aW9uL2V4aGliaXRpb24uanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3N2ZzRldmVyeWJvZHkvZGlzdC9zdmc0ZXZlcnlib2R5LmpzIl0sIm5hbWVzIjpbIiQiLCJzdmc0ZXZlcnlib2R5Iiwic3R5bGVzIiwiam9pbiIsImNvbnNvbGUiLCJsb2ciLCJsYXp5TG9hZEluc3RhbmNlIiwiTGF6eUxvYWQiLCJlbGVtZW50c19zZWxlY3RvciIsInVzZV9uYXRpdmUiLCJ1cGRhdGUiLCIkaEJ1dHRvbiIsIiRoTGlzdCIsIm9uIiwidG9nZ2xlQ2xhc3MiLCJkb2N1bWVudCIsImUiLCJ0YXJnZXQiLCJjbG9zZXN0IiwibGVuZ3RoIiwicmVtb3ZlQ2xhc3MiLCJwcmV2ZW50RGVmYXVsdCIsIm9mZnNldExlZnQiLCJwYWdlWCIsIm9mZnNldFJpZ2h0Iiwib3V0ZXJXaWR0aCIsInNpYmxpbmdzIiwicHJldiIsImV4aGliaXRpb25TbGlkZXIiLCJhYm91dFNsaWRlciIsImpRdWVyeSIsIm1vZHVsZSIsImV4cG9ydHMiLCIkYWJvdXRTbGlkZXIiLCJzbGljayIsInNsaWRlc1RvU2Nyb2xsIiwiZG90cyIsIm1vYmlsZUZpcnN0IiwibG9vcCIsImxhenlMb2FkIiwic3BlZWQiLCJmb2N1c09uU2VsZWN0Iiwid2FpdEZvckFuaW1hdGUiLCJwcmV2QXJyb3ciLCJuZXh0QXJyb3ciLCJyZXNwb25zaXZlIiwiYnJlYWtwb2ludCIsInNldHRpbmdzIiwic2xpZGVzVG9TaG93IiwiJGV4aGliaXRpb25TbGlkZXIiLCJmYWRlIiwiYXBwZW5kRG90cyIsImFkYXB0aXZlSGVpZ2h0IiwiYXNOYXZGb3IiLCJhcnJvd3MiXSwibWFwcGluZ3MiOiI7UUFBQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTs7O1FBR0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDBDQUEwQyxnQ0FBZ0M7UUFDMUU7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSx3REFBd0Qsa0JBQWtCO1FBQzFFO1FBQ0EsaURBQWlELGNBQWM7UUFDL0Q7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLHlDQUF5QyxpQ0FBaUM7UUFDMUUsZ0hBQWdILG1CQUFtQixFQUFFO1FBQ3JJO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMkJBQTJCLDBCQUEwQixFQUFFO1FBQ3ZELGlDQUFpQyxlQUFlO1FBQ2hEO1FBQ0E7UUFDQTs7UUFFQTtRQUNBLHNEQUFzRCwrREFBK0Q7O1FBRXJIO1FBQ0E7OztRQUdBO1FBQ0E7Ozs7Ozs7Ozs7Ozs7QUNsRkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0NBR0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQSxDQUFDLFVBQVVBLENBQVYsRUFBYTtBQUVaQyxzREFBYTtBQUViLE1BQUlDLE1BQU0sR0FBRyxDQUNYLGtCQURXLEVBRVgscUJBRlcsRUFHWCxhQUhXLEVBSVgsdUJBSlcsRUFLWCwwSUFMVyxFQU1YLG1CQU5XLEVBT1gsa0JBUFcsRUFRWCxpQkFSVyxFQVNYLGtCQVRXLEVBVVhDLElBVlcsQ0FVTixHQVZNLENBQWI7QUFZQUMsU0FBTyxDQUFDQyxHQUFSLENBQVksOENBQVosRUFBNkRILE1BQTdEO0FBR0E7Ozs7QUFLQSxNQUFJSSxnQkFBZ0IsR0FBRyxJQUFJQyxRQUFKLENBQWE7QUFDbENDLHFCQUFpQixFQUFFLE9BRGU7QUFFbEM7QUFDQUMsY0FBVSxFQUFFO0FBSHNCLEdBQWIsQ0FBdkI7O0FBT0EsTUFBSUgsZ0JBQUosRUFBc0I7QUFDcEJBLG9CQUFnQixDQUFDSSxNQUFqQjtBQUNEOztBQUdEVixHQUFDLENBQUMsWUFBVztBQUVYLFFBQUlXLFFBQVEsR0FBR1gsQ0FBQyxDQUFDLGlCQUFELENBQWhCO0FBQ0EsUUFBSVksTUFBTSxHQUFHWixDQUFDLENBQUMsZUFBRCxDQUFkO0FBRUFXLFlBQVEsQ0FBQ0UsRUFBVCxDQUFZLE9BQVosRUFBcUIsWUFBWTtBQUMvQlQsYUFBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUNBTyxZQUFNLENBQUNFLFdBQVAsQ0FBbUIscUJBQW5CO0FBR0QsS0FMRDtBQU9BZCxLQUFDLENBQUNlLFFBQUQsQ0FBRCxDQUFZRixFQUFaLENBQWUsT0FBZixFQUF3QixVQUFTRyxDQUFULEVBQVk7QUFDbEMsVUFBSSxDQUFDaEIsQ0FBQyxDQUFDZ0IsQ0FBQyxDQUFDQyxNQUFILENBQUQsQ0FBWUMsT0FBWixDQUFvQixpQkFBcEIsRUFBdUNDLE1BQTVDLEVBQW9EO0FBQ2xEUCxjQUFNLENBQUNRLFdBQVAsQ0FBbUIscUJBQW5CO0FBQ0Q7QUFDRixLQUpEO0FBT0FwQixLQUFDLENBQUMsY0FBRCxDQUFELENBQWtCYSxFQUFsQixDQUFxQixPQUFyQixFQUE4QixVQUFVRyxDQUFWLEVBQWE7QUFDekNBLE9BQUMsQ0FBQ0ssY0FBRjtBQUVBckIsT0FBQyxDQUFDLGNBQUQsQ0FBRCxDQUFrQmMsV0FBbEIsQ0FBOEIsWUFBOUI7QUFFRCxLQUxEO0FBUUFkLEtBQUMsQ0FBQ2UsUUFBRCxDQUFELENBQVlGLEVBQVosQ0FBZSxPQUFmLEVBQXdCLFVBQVNHLENBQVQsRUFBWTtBQUNsQyxVQUFJLENBQUNoQixDQUFDLENBQUNnQixDQUFDLENBQUNDLE1BQUgsQ0FBRCxDQUFZQyxPQUFaLENBQW9CLGNBQXBCLEVBQW9DQyxNQUF6QyxFQUFpRDtBQUMvQ25CLFNBQUMsQ0FBQyxjQUFELENBQUQsQ0FBa0JvQixXQUFsQixDQUE4QixZQUE5QjtBQUNEO0FBQ0YsS0FKRDtBQVFBcEIsS0FBQyxDQUFDLG9CQUFELENBQUQsQ0FBd0JhLEVBQXhCLENBQTRCLE9BQTVCLEVBQXFDLFVBQVVHLENBQVYsRUFBYTtBQUNoREEsT0FBQyxDQUFDSyxjQUFGO0FBQ0FqQixhQUFPLENBQUNDLEdBQVIsQ0FBWVcsQ0FBWjtBQUNBLFVBQUlNLFVBQVUsR0FBR04sQ0FBQyxDQUFDTyxLQUFuQjtBQUNBLFVBQUlDLFdBQVcsR0FBS3hCLENBQUMsQ0FBQyxrQkFBRCxDQUFELENBQXNCeUIsVUFBdEIsS0FBcUNULENBQUMsQ0FBQ08sS0FBeEMsR0FBaUQsRUFBcEU7QUFFQW5CLGFBQU8sQ0FBQ0MsR0FBUixDQUFZaUIsVUFBWjtBQUNBbEIsYUFBTyxDQUFDQyxHQUFSLENBQWFMLENBQUMsQ0FBQyxrQkFBRCxDQUFELENBQXNCeUIsVUFBdEIsRUFBYixFQVBnRCxDQVNoRDs7QUFFQXpCLE9BQUMsQ0FBQyxJQUFELENBQUQsQ0FBUWMsV0FBUixDQUFvQiwwQkFBcEI7QUFDQWQsT0FBQyxDQUFDLElBQUQsQ0FBRCxDQUFRMEIsUUFBUixHQUFtQk4sV0FBbkIsQ0FBK0IsMEJBQS9CO0FBQ0FwQixPQUFDLENBQUMsSUFBRCxDQUFELENBQVEyQixJQUFSLENBQWEsZUFBYixFQUE4QmIsV0FBOUIsQ0FBMEMscUJBQTFDO0FBQ0FkLE9BQUMsQ0FBQyxJQUFELENBQUQsQ0FBUTBCLFFBQVIsR0FBbUJDLElBQW5CLENBQXdCLGVBQXhCLEVBQXlDUCxXQUF6QyxDQUFxRCxxQkFBckQsRUFkZ0QsQ0FnQmhEO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFRCxLQTNCRCxFQW5DVyxDQWlFWDs7QUFFQVEsd0VBQWdCO0FBQ2hCQyw4REFBVztBQUtaLEdBekVBLENBQUQ7QUE4RUQsQ0FsSEQsRUFrSEdDLE1BbEhILEU7Ozs7Ozs7Ozs7O0FDWEFDLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQixTQUFTSCxXQUFULEdBQXdCO0FBRXJDLE1BQUlJLFlBQVksR0FBR2pDLENBQUMsQ0FBQyxnQkFBRCxDQUFwQjs7QUFFQSxNQUFJaUMsWUFBWSxDQUFDZCxNQUFiLEdBQXNCLENBQTFCLEVBQThCO0FBRTVCYyxnQkFBWSxDQUFDQyxLQUFiLENBQW1CO0FBQ2pCQyxvQkFBYyxFQUFFLENBREM7QUFFakJDLFVBQUksRUFBRSxLQUZXO0FBR2pCQyxpQkFBVyxFQUFFLElBSEk7QUFJakI7QUFDQUMsVUFBSSxFQUFFLElBTFc7QUFNakJDLGNBQVEsRUFBRSxVQU5PO0FBT2pCO0FBQ0FDLFdBQUssRUFBRSxHQVJVO0FBU2pCQyxtQkFBYSxFQUFFLElBVEU7QUFVakJDLG9CQUFjLEVBQUUsS0FWQztBQVdqQjtBQUNBO0FBQ0FDLGVBQVMsRUFBRSx3QkFiTTtBQWNqQkMsZUFBUyxFQUFFLHdCQWRNO0FBZ0JqQkMsZ0JBQVUsRUFBRSxDQUNWO0FBQ0VDLGtCQUFVLEVBQUUsQ0FEZDtBQUVFQyxnQkFBUSxFQUFFO0FBQ1JDLHNCQUFZLEVBQUU7QUFETjtBQUZaLE9BRFUsRUFPVjtBQUNFRixrQkFBVSxFQUFFLEdBRGQ7QUFFRUMsZ0JBQVEsRUFBRTtBQUNSQyxzQkFBWSxFQUFFO0FBRE47QUFGWixPQVBVO0FBaEJLLEtBQW5CO0FBaUNEO0FBRUosQ0F6Q0QsQzs7Ozs7Ozs7Ozs7QUNBQWpCLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQixTQUFTSixnQkFBVCxHQUE2QjtBQUUxQyxNQUFJcUIsaUJBQWlCLEdBQUdqRCxDQUFDLENBQUMscUJBQUQsQ0FBekI7O0FBRUEsTUFBSWlELGlCQUFpQixDQUFDOUIsTUFBbEIsR0FBMkIsQ0FBL0IsRUFBbUM7QUFFakM4QixxQkFBaUIsQ0FBQ2YsS0FBbEIsQ0FBd0I7QUFDdEJDLG9CQUFjLEVBQUUsQ0FETTtBQUV0QkMsVUFBSSxFQUFFLElBRmdCO0FBR3RCQyxpQkFBVyxFQUFFLElBSFM7QUFJdEI7QUFDQUMsVUFBSSxFQUFFLElBTGdCO0FBTXRCQyxjQUFRLEVBQUUsVUFOWTtBQU90QlcsVUFBSSxFQUFFLElBUGdCO0FBUXRCVixXQUFLLEVBQUUsR0FSZTtBQVN0QkMsbUJBQWEsRUFBRSxJQVRPO0FBVXRCQyxvQkFBYyxFQUFFLEtBVk07QUFXdEI7QUFDQVMsZ0JBQVUsRUFBRW5ELENBQUMsQ0FBQyxtQkFBRCxDQVpTO0FBYXRCMkMsZUFBUyxFQUFFLHlCQWJXO0FBY3RCQyxlQUFTLEVBQUUseUJBZFc7QUFnQnRCQyxnQkFBVSxFQUFFLENBQ1Y7QUFDRUMsa0JBQVUsRUFBRSxDQURkO0FBRUVDLGdCQUFRLEVBQUU7QUFDUkMsc0JBQVksRUFBRTtBQUROO0FBRlosT0FEVSxFQU9WO0FBQ0VGLGtCQUFVLEVBQUUsR0FEZDtBQUVFQyxnQkFBUSxFQUFFO0FBQ1JDLHNCQUFZLEVBQUU7QUFETjtBQUZaLE9BUFU7QUFoQlUsS0FBeEI7QUFpQ0FoRCxLQUFDLENBQUMscUJBQUQsQ0FBRCxDQUF5QmtDLEtBQXpCLENBQStCO0FBQzdCYyxrQkFBWSxFQUFFLENBRGU7QUFFN0JiLG9CQUFjLEVBQUUsQ0FGYTtBQUc3QkUsaUJBQVcsRUFBRSxJQUhnQjtBQUk3QmUsb0JBQWMsRUFBRSxJQUphO0FBSzdCQyxjQUFRLEVBQUUscUJBTG1CO0FBTTdCakIsVUFBSSxFQUFFLEtBTnVCO0FBTzdCa0IsWUFBTSxFQUFFLEtBUHFCO0FBUTdCO0FBQ0FiLG1CQUFhLEVBQUUsSUFUYztBQVU3QkksZ0JBQVUsRUFBRSxDQUNWO0FBQ0VDLGtCQUFVLEVBQUUsQ0FEZDtBQUVFQyxnQkFBUSxFQUFFO0FBQ1JDLHNCQUFZLEVBQUU7QUFETjtBQUZaLE9BRFUsRUFPVjtBQUNFRixrQkFBVSxFQUFFLEdBRGQ7QUFFRUMsZ0JBQVEsRUFBRTtBQUNSQyxzQkFBWSxFQUFFO0FBRE47QUFGWixPQVBVO0FBVmlCLEtBQS9CO0FBNkJEO0FBRUosQ0F0RUQsQzs7Ozs7Ozs7Ozs7QUNBQTtBQUNBLElBQUksS0FBeUM7QUFDN0MsSUFBSSxpQ0FBTyxFQUFFLG1DQUFFO0FBQ2Y7QUFDQSxLQUFLO0FBQUEsb0dBQUMsR0FBRyxTQUdzRDtBQUMvRCxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2Q0FBNkMseUJBQXlCO0FBQ3RFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdGQUF3RjtBQUN4RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIscUJBQXFCO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQztBQUNqQztBQUNBLDZCQUE2QjtBQUM3QjtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsZ0VBQWdFO0FBQzVGO0FBQ0E7QUFDQTtBQUNBLENBQUMsRSIsImZpbGUiOiJtYWluLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZ2V0dGVyIH0pO1xuIFx0XHR9XG4gXHR9O1xuXG4gXHQvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSBmdW5jdGlvbihleHBvcnRzKSB7XG4gXHRcdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuIFx0XHR9XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG4gXHR9O1xuXG4gXHQvLyBjcmVhdGUgYSBmYWtlIG5hbWVzcGFjZSBvYmplY3RcbiBcdC8vIG1vZGUgJiAxOiB2YWx1ZSBpcyBhIG1vZHVsZSBpZCwgcmVxdWlyZSBpdFxuIFx0Ly8gbW9kZSAmIDI6IG1lcmdlIGFsbCBwcm9wZXJ0aWVzIG9mIHZhbHVlIGludG8gdGhlIG5zXG4gXHQvLyBtb2RlICYgNDogcmV0dXJuIHZhbHVlIHdoZW4gYWxyZWFkeSBucyBvYmplY3RcbiBcdC8vIG1vZGUgJiA4fDE6IGJlaGF2ZSBsaWtlIHJlcXVpcmVcbiBcdF9fd2VicGFja19yZXF1aXJlX18udCA9IGZ1bmN0aW9uKHZhbHVlLCBtb2RlKSB7XG4gXHRcdGlmKG1vZGUgJiAxKSB2YWx1ZSA9IF9fd2VicGFja19yZXF1aXJlX18odmFsdWUpO1xuIFx0XHRpZihtb2RlICYgOCkgcmV0dXJuIHZhbHVlO1xuIFx0XHRpZigobW9kZSAmIDQpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgJiYgdmFsdWUuX19lc01vZHVsZSkgcmV0dXJuIHZhbHVlO1xuIFx0XHR2YXIgbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIobnMpO1xuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobnMsICdkZWZhdWx0JywgeyBlbnVtZXJhYmxlOiB0cnVlLCB2YWx1ZTogdmFsdWUgfSk7XG4gXHRcdGlmKG1vZGUgJiAyICYmIHR5cGVvZiB2YWx1ZSAhPSAnc3RyaW5nJykgZm9yKHZhciBrZXkgaW4gdmFsdWUpIF9fd2VicGFja19yZXF1aXJlX18uZChucywga2V5LCBmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHZhbHVlW2tleV07IH0uYmluZChudWxsLCBrZXkpKTtcbiBcdFx0cmV0dXJuIG5zO1xuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCIuL2Fzc2V0cy9qcy9cIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IFwiLi9tYXJrdXAvYXNzZXRzL2pzL21haW4uanNcIik7XG4iLCJpbXBvcnQgc3ZnNGV2ZXJ5Ym9keSBmcm9tICdzdmc0ZXZlcnlib2R5JztcbmltcG9ydCBleGhpYml0aW9uU2xpZGVyIGZyb20gJy4uLy4uL2Jsb2Nrcy9leGhpYml0aW9uL2V4aGliaXRpb24nO1xuaW1wb3J0IGFib3V0U2xpZGVyIGZyb20gJy4uLy4uL2Jsb2Nrcy9hYm91dC9hYm91dCc7XG5cbi8vIGltcG9ydCBsZXZlbHNTbGlkZXIgZnJvbSAnLi4vLi4vYmxvY2tzL2xldmVscy9sZXZlbHMnO1xuLy8gaW1wb3J0IHBheW1lbnRTbGlkZXIgZnJvbSAnLi4vLi4vYmxvY2tzL3BheW1lbnQvcGF5bWVudCc7XG4vLyBpbXBvcnQgZmFxIGZyb20gJy4uLy4uL2Jsb2Nrcy9mYXEvZmFxJztcblxuLy8gaW1wb3J0ICQgZnJvbSAnanF1ZXJ5Jztcbi8vIGltcG9ydCBzbGljayBmcm9tICdzbGljay1jYXJvdXNlbCc7XG5cbihmdW5jdGlvbiAoJCkge1xuXG4gIHN2ZzRldmVyeWJvZHkoKTtcblxuICBsZXQgc3R5bGVzID0gW1xuICAgICdwYWRkaW5nOiAycHggOXB4JyxcbiAgICAnYmFja2dyb3VuZDogIzI5NDhmZicsXG4gICAgJ2NvbG9yOiAjZmZmJyxcbiAgICAnZGlzcGxheTogaW5saW5lLWJsb2NrJyxcbiAgICAnYm94LXNoYWRvdzogMCAtMXB4IDAgcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjIpIGluc2V0LCAwIDVweCAzcHggLTVweCByZ2JhKDAsIDAsIDAsIDAuNSksIDAgLTEzcHggNXB4IC0xMHB4IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC40KSBpbnNldCcsXG4gICAgJ2xpbmUtaGVpZ2h0OiAxLjU2JyxcbiAgICAndGV4dC1hbGlnbjogbGVmdCcsXG4gICAgJ2ZvbnQtc2l6ZTogMTZweCcsXG4gICAgJ2ZvbnQtd2VpZ2h0OiA0MDAnXG4gIF0uam9pbignOycpO1xuXG4gIGNvbnNvbGUubG9nKCclYyBkZXZlbG9wZWQgYnkgaWdvciBnb3Jsb3YgaHR0cHM6Ly9pZ3Jsdi5ydScgLCBzdHlsZXMpO1xuXG5cbiAgLypcbiAgICBMYXp5bG9hZCBpbWFnZXNcbiAgKi9cblxuXG4gIGxldCBsYXp5TG9hZEluc3RhbmNlID0gbmV3IExhenlMb2FkKHtcbiAgICBlbGVtZW50c19zZWxlY3RvcjogJy5sYXp5JyxcbiAgICAvLyBsb2FkX2RlbGF5OiA1MDAsXG4gICAgdXNlX25hdGl2ZTogdHJ1ZVxuICB9KTtcblxuXG4gIGlmIChsYXp5TG9hZEluc3RhbmNlKSB7XG4gICAgbGF6eUxvYWRJbnN0YW5jZS51cGRhdGUoKTtcbiAgfVxuXG5cbiAgJChmdW5jdGlvbigpIHtcblxuICAgIGxldCAkaEJ1dHRvbiA9ICQoJy5oLXVzZXJfX2J1dHRvbicpO1xuICAgIGxldCAkaExpc3QgPSAkKCcuaC11c2VyX19saXN0Jyk7XG5cbiAgICAkaEJ1dHRvbi5vbignY2xpY2snLCBmdW5jdGlvbiAoKSB7XG4gICAgICBjb25zb2xlLmxvZygnY2xpY2snKTtcbiAgICAgICRoTGlzdC50b2dnbGVDbGFzcygnaC11c2VyX19saXN0X2FjdGl2ZScpO1xuXG5cbiAgICB9KTtcblxuICAgICQoZG9jdW1lbnQpLm9uKCdjbGljaycsIGZ1bmN0aW9uKGUpIHtcbiAgICAgIGlmICghJChlLnRhcmdldCkuY2xvc2VzdCgnLmgtdXNlcl9fYnV0dG9uJykubGVuZ3RoKSB7XG4gICAgICAgICRoTGlzdC5yZW1vdmVDbGFzcygnaC11c2VyX19saXN0X2FjdGl2ZScpO1xuICAgICAgfVxuICAgIH0pO1xuXG5cbiAgICAkKCcubmF2X19idXR0b24nKS5vbignY2xpY2snLCBmdW5jdGlvbiAoZSkge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICAgICQoJy5oZWFkZXJfX25hdicpLnRvZ2dsZUNsYXNzKCduYXZfYWN0aXZlJyk7XG5cbiAgICB9KTtcblxuXG4gICAgJChkb2N1bWVudCkub24oJ2NsaWNrJywgZnVuY3Rpb24oZSkge1xuICAgICAgaWYgKCEkKGUudGFyZ2V0KS5jbG9zZXN0KCcubmF2X19idXR0b24nKS5sZW5ndGgpIHtcbiAgICAgICAgJCgnLmhlYWRlcl9fbmF2JykucmVtb3ZlQ2xhc3MoJ25hdl9hY3RpdmUnKTtcbiAgICAgIH1cbiAgICB9KTtcblxuXG5cbiAgICAkKCcuY2F0YWxvZ19fY2F0ZWdvcnknKS5vbiggJ2NsaWNrJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgbGV0IG9mZnNldExlZnQgPSBlLnBhZ2VYO1xuICAgICAgbGV0IG9mZnNldFJpZ2h0ID0gKCgkKCcuY2F0YWxvZ19fYm90dG9tJykub3V0ZXJXaWR0aCgpIC0gZS5wYWdlWCkgLSA2MCk7XG5cbiAgICAgIGNvbnNvbGUubG9nKG9mZnNldExlZnQpO1xuICAgICAgY29uc29sZS5sb2coICQoJy5jYXRhbG9nX19ib3R0b20nKS5vdXRlcldpZHRoKCkgKTtcblxuICAgICAgLy8gJCh0aGlzKS5wcmV2KCkudG9nZ2xlQ2xhc3MoJ2NhdGFsb2dfX3N1Yl9hY3RpdmUnKTtcblxuICAgICAgJCh0aGlzKS50b2dnbGVDbGFzcygnY2F0YWxvZ19fY2F0ZWdvcnlfYWN0aXZlJyk7XG4gICAgICAkKHRoaXMpLnNpYmxpbmdzKCkucmVtb3ZlQ2xhc3MoJ2NhdGFsb2dfX2NhdGVnb3J5X2FjdGl2ZScpO1xuICAgICAgJCh0aGlzKS5wcmV2KCcuY2F0YWxvZ19fc3ViJykudG9nZ2xlQ2xhc3MoJ2NhdGFsb2dfX3N1Yl9hY3RpdmUnKTtcbiAgICAgICQodGhpcykuc2libGluZ3MoKS5wcmV2KCcuY2F0YWxvZ19fc3ViJykucmVtb3ZlQ2xhc3MoJ2NhdGFsb2dfX3N1Yl9hY3RpdmUnKTtcblxuICAgICAgLy8gJCh0aGlzKS5maW5kKCcuY2F0YWxvZ19fc3ViJykuY3NzKCdsZWZ0JywgKG9mZnNldExlZnQgKyA2MCkgKyAncHgnKTtcblxuICAgICAgLy8gaWYoICgkKCcuY2F0YWxvZ19fYm90dG9tJykub3V0ZXJXaWR0aCgpIC8gMikgPCA1ODUgKSB7XG4gICAgICAvLyAgICQodGhpcykuZmluZCgnLmNhdGFsb2dfX3N1Yi10cmlhbmdsZScpLmNzcygncmlnaHQnLCArICdhdXRvJyk7XG4gICAgICAvLyAgICQodGhpcykuZmluZCgnLmNhdGFsb2dfX3N1Yi10cmlhbmdsZScpLmNzcygnbGVmdCcsIChvZmZzZXRMZWZ0KSArICdweCcpO1xuXG4gICAgICAvLyB9IGVsc2Uge1xuICAgICAgLy8gICAkKHRoaXMpLmZpbmQoJy5jYXRhbG9nX19zdWInKS5jc3MoJ2xlZnQnLCAnYXV0bycpO1xuICAgICAgLy8gICAkKHRoaXMpLmZpbmQoJy5jYXRhbG9nX19zdWInKS5jc3MoJ3JpZ2h0JywgKG9mZnNldFJpZ2h0KSArICdweCcpO1xuICAgICAgLy8gfVxuXG4gICAgfSk7XG5cblxuICAgIC8vIFNsaWRlcnNcblxuICAgIGV4aGliaXRpb25TbGlkZXIoKTtcbiAgICBhYm91dFNsaWRlcigpO1xuXG5cblxuXG4gIH0pO1xuXG5cblxuXG59KShqUXVlcnkpO1xuIiwibW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBhYm91dFNsaWRlciAoKSB7XG5cbiAgICBsZXQgJGFib3V0U2xpZGVyID0gJCgnLmFib3V0X19zbGlkZXInKTtcblxuICAgIGlmKCAkYWJvdXRTbGlkZXIubGVuZ3RoID4gMCApIHtcblxuICAgICAgJGFib3V0U2xpZGVyLnNsaWNrKHtcbiAgICAgICAgc2xpZGVzVG9TY3JvbGw6IDEsXG4gICAgICAgIGRvdHM6IGZhbHNlLFxuICAgICAgICBtb2JpbGVGaXJzdDogdHJ1ZSxcbiAgICAgICAgLy8gaW5maW5pdGU6IGZhbHNlLFxuICAgICAgICBsb29wOiB0cnVlLFxuICAgICAgICBsYXp5TG9hZDogJ29uZGVtYW5kJyxcbiAgICAgICAgLy8gZmFkZTogdHJ1ZSxcbiAgICAgICAgc3BlZWQ6IDMwMCxcbiAgICAgICAgZm9jdXNPblNlbGVjdDogdHJ1ZSxcbiAgICAgICAgd2FpdEZvckFuaW1hdGU6IGZhbHNlLFxuICAgICAgICAvLyBhcnJvd3M6IGZhbHNlLFxuICAgICAgICAvLyBhcHBlbmREb3RzOiAkKCcuZXhoaWJpdGlvbl9fZG90cycpLFxuICAgICAgICBwcmV2QXJyb3c6ICcuYWJvdXRfX25hdi1hcnJvd19iYWNrJyxcbiAgICAgICAgbmV4dEFycm93OiAnLmFib3V0X19uYXYtYXJyb3dfbmV4dCcsXG5cbiAgICAgICAgcmVzcG9uc2l2ZTogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGJyZWFrcG9pbnQ6IDEsXG4gICAgICAgICAgICBzZXR0aW5nczoge1xuICAgICAgICAgICAgICBzbGlkZXNUb1Nob3c6IDEsXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBicmVha3BvaW50OiA2MDAsXG4gICAgICAgICAgICBzZXR0aW5nczoge1xuICAgICAgICAgICAgICBzbGlkZXNUb1Nob3c6IDEsXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICBdXG4gICAgICB9KTtcblxuXG4gICAgfVxuXG59XG5cbiIsIm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gZXhoaWJpdGlvblNsaWRlciAoKSB7XG5cbiAgICBsZXQgJGV4aGliaXRpb25TbGlkZXIgPSAkKCcuZXhoaWJpdGlvbl9fc2xpZGVyJyk7XG5cbiAgICBpZiggJGV4aGliaXRpb25TbGlkZXIubGVuZ3RoID4gMCApIHtcblxuICAgICAgJGV4aGliaXRpb25TbGlkZXIuc2xpY2soe1xuICAgICAgICBzbGlkZXNUb1Njcm9sbDogMSxcbiAgICAgICAgZG90czogdHJ1ZSxcbiAgICAgICAgbW9iaWxlRmlyc3Q6IHRydWUsXG4gICAgICAgIC8vIGluZmluaXRlOiBmYWxzZSxcbiAgICAgICAgbG9vcDogdHJ1ZSxcbiAgICAgICAgbGF6eUxvYWQ6ICdvbmRlbWFuZCcsXG4gICAgICAgIGZhZGU6IHRydWUsXG4gICAgICAgIHNwZWVkOiAzMDAsXG4gICAgICAgIGZvY3VzT25TZWxlY3Q6IHRydWUsXG4gICAgICAgIHdhaXRGb3JBbmltYXRlOiBmYWxzZSxcbiAgICAgICAgLy8gYXJyb3dzOiBmYWxzZSxcbiAgICAgICAgYXBwZW5kRG90czogJCgnLmV4aGliaXRpb25fX2RvdHMnKSxcbiAgICAgICAgcHJldkFycm93OiAnLmV4aGliaXRpb25fX2Fycm93X2JhY2snLFxuICAgICAgICBuZXh0QXJyb3c6ICcuZXhoaWJpdGlvbl9fYXJyb3dfbmV4dCcsXG5cbiAgICAgICAgcmVzcG9uc2l2ZTogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGJyZWFrcG9pbnQ6IDEsXG4gICAgICAgICAgICBzZXR0aW5nczoge1xuICAgICAgICAgICAgICBzbGlkZXNUb1Nob3c6IDEsXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBicmVha3BvaW50OiA2MDAsXG4gICAgICAgICAgICBzZXR0aW5nczoge1xuICAgICAgICAgICAgICBzbGlkZXNUb1Nob3c6IDEsXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICBdXG4gICAgICB9KTtcblxuXG4gICAgICAkKCcuZXhoaWJpdGlvbl9fdGh1bWJzJykuc2xpY2soe1xuICAgICAgICBzbGlkZXNUb1Nob3c6IDQsXG4gICAgICAgIHNsaWRlc1RvU2Nyb2xsOiAxLFxuICAgICAgICBtb2JpbGVGaXJzdDogdHJ1ZSxcbiAgICAgICAgYWRhcHRpdmVIZWlnaHQ6IHRydWUsXG4gICAgICAgIGFzTmF2Rm9yOiAnLmV4aGliaXRpb25fX3NsaWRlcicsXG4gICAgICAgIGRvdHM6IGZhbHNlLFxuICAgICAgICBhcnJvd3M6IGZhbHNlLFxuICAgICAgICAvLyBjZW50ZXJNb2RlOiB0cnVlLFxuICAgICAgICBmb2N1c09uU2VsZWN0OiB0cnVlLFxuICAgICAgICByZXNwb25zaXZlOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgYnJlYWtwb2ludDogMSxcbiAgICAgICAgICAgIHNldHRpbmdzOiB7XG4gICAgICAgICAgICAgIHNsaWRlc1RvU2hvdzogMixcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGJyZWFrcG9pbnQ6IDYwMCxcbiAgICAgICAgICAgIHNldHRpbmdzOiB7XG4gICAgICAgICAgICAgIHNsaWRlc1RvU2hvdzogNCxcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICAgIH0pO1xuXG5cblxuXG4gICAgfVxuXG59XG5cbiIsIiFmdW5jdGlvbihyb290LCBmYWN0b3J5KSB7XG4gICAgXCJmdW5jdGlvblwiID09IHR5cGVvZiBkZWZpbmUgJiYgZGVmaW5lLmFtZCA/IC8vIEFNRC4gUmVnaXN0ZXIgYXMgYW4gYW5vbnltb3VzIG1vZHVsZSB1bmxlc3MgYW1kTW9kdWxlSWQgaXMgc2V0XG4gICAgZGVmaW5lKFtdLCBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHJvb3Quc3ZnNGV2ZXJ5Ym9keSA9IGZhY3RvcnkoKTtcbiAgICB9KSA6IFwib2JqZWN0XCIgPT0gdHlwZW9mIG1vZHVsZSAmJiBtb2R1bGUuZXhwb3J0cyA/IC8vIE5vZGUuIERvZXMgbm90IHdvcmsgd2l0aCBzdHJpY3QgQ29tbW9uSlMsIGJ1dFxuICAgIC8vIG9ubHkgQ29tbW9uSlMtbGlrZSBlbnZpcm9ubWVudHMgdGhhdCBzdXBwb3J0IG1vZHVsZS5leHBvcnRzLFxuICAgIC8vIGxpa2UgTm9kZS5cbiAgICBtb2R1bGUuZXhwb3J0cyA9IGZhY3RvcnkoKSA6IHJvb3Quc3ZnNGV2ZXJ5Ym9keSA9IGZhY3RvcnkoKTtcbn0odGhpcywgZnVuY3Rpb24oKSB7XG4gICAgLyohIHN2ZzRldmVyeWJvZHkgdjIuMS45IHwgZ2l0aHViLmNvbS9qb25hdGhhbnRuZWFsL3N2ZzRldmVyeWJvZHkgKi9cbiAgICBmdW5jdGlvbiBlbWJlZChwYXJlbnQsIHN2ZywgdGFyZ2V0KSB7XG4gICAgICAgIC8vIGlmIHRoZSB0YXJnZXQgZXhpc3RzXG4gICAgICAgIGlmICh0YXJnZXQpIHtcbiAgICAgICAgICAgIC8vIGNyZWF0ZSBhIGRvY3VtZW50IGZyYWdtZW50IHRvIGhvbGQgdGhlIGNvbnRlbnRzIG9mIHRoZSB0YXJnZXRcbiAgICAgICAgICAgIHZhciBmcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKSwgdmlld0JveCA9ICFzdmcuaGFzQXR0cmlidXRlKFwidmlld0JveFwiKSAmJiB0YXJnZXQuZ2V0QXR0cmlidXRlKFwidmlld0JveFwiKTtcbiAgICAgICAgICAgIC8vIGNvbmRpdGlvbmFsbHkgc2V0IHRoZSB2aWV3Qm94IG9uIHRoZSBzdmdcbiAgICAgICAgICAgIHZpZXdCb3ggJiYgc3ZnLnNldEF0dHJpYnV0ZShcInZpZXdCb3hcIiwgdmlld0JveCk7XG4gICAgICAgICAgICAvLyBjb3B5IHRoZSBjb250ZW50cyBvZiB0aGUgY2xvbmUgaW50byB0aGUgZnJhZ21lbnRcbiAgICAgICAgICAgIGZvciAoLy8gY2xvbmUgdGhlIHRhcmdldFxuICAgICAgICAgICAgdmFyIGNsb25lID0gdGFyZ2V0LmNsb25lTm9kZSghMCk7IGNsb25lLmNoaWxkTm9kZXMubGVuZ3RoOyApIHtcbiAgICAgICAgICAgICAgICBmcmFnbWVudC5hcHBlbmRDaGlsZChjbG9uZS5maXJzdENoaWxkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIGFwcGVuZCB0aGUgZnJhZ21lbnQgaW50byB0aGUgc3ZnXG4gICAgICAgICAgICBwYXJlbnQuYXBwZW5kQ2hpbGQoZnJhZ21lbnQpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIGxvYWRyZWFkeXN0YXRlY2hhbmdlKHhocikge1xuICAgICAgICAvLyBsaXN0ZW4gdG8gY2hhbmdlcyBpbiB0aGUgcmVxdWVzdFxuICAgICAgICB4aHIub25yZWFkeXN0YXRlY2hhbmdlID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAvLyBpZiB0aGUgcmVxdWVzdCBpcyByZWFkeVxuICAgICAgICAgICAgaWYgKDQgPT09IHhoci5yZWFkeVN0YXRlKSB7XG4gICAgICAgICAgICAgICAgLy8gZ2V0IHRoZSBjYWNoZWQgaHRtbCBkb2N1bWVudFxuICAgICAgICAgICAgICAgIHZhciBjYWNoZWREb2N1bWVudCA9IHhoci5fY2FjaGVkRG9jdW1lbnQ7XG4gICAgICAgICAgICAgICAgLy8gZW5zdXJlIHRoZSBjYWNoZWQgaHRtbCBkb2N1bWVudCBiYXNlZCBvbiB0aGUgeGhyIHJlc3BvbnNlXG4gICAgICAgICAgICAgICAgY2FjaGVkRG9jdW1lbnQgfHwgKGNhY2hlZERvY3VtZW50ID0geGhyLl9jYWNoZWREb2N1bWVudCA9IGRvY3VtZW50LmltcGxlbWVudGF0aW9uLmNyZWF0ZUhUTUxEb2N1bWVudChcIlwiKSwgXG4gICAgICAgICAgICAgICAgY2FjaGVkRG9jdW1lbnQuYm9keS5pbm5lckhUTUwgPSB4aHIucmVzcG9uc2VUZXh0LCB4aHIuX2NhY2hlZFRhcmdldCA9IHt9KSwgLy8gY2xlYXIgdGhlIHhociBlbWJlZHMgbGlzdCBhbmQgZW1iZWQgZWFjaCBpdGVtXG4gICAgICAgICAgICAgICAgeGhyLl9lbWJlZHMuc3BsaWNlKDApLm1hcChmdW5jdGlvbihpdGVtKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGdldCB0aGUgY2FjaGVkIHRhcmdldFxuICAgICAgICAgICAgICAgICAgICB2YXIgdGFyZ2V0ID0geGhyLl9jYWNoZWRUYXJnZXRbaXRlbS5pZF07XG4gICAgICAgICAgICAgICAgICAgIC8vIGVuc3VyZSB0aGUgY2FjaGVkIHRhcmdldFxuICAgICAgICAgICAgICAgICAgICB0YXJnZXQgfHwgKHRhcmdldCA9IHhoci5fY2FjaGVkVGFyZ2V0W2l0ZW0uaWRdID0gY2FjaGVkRG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaXRlbS5pZCkpLCBcbiAgICAgICAgICAgICAgICAgICAgLy8gZW1iZWQgdGhlIHRhcmdldCBpbnRvIHRoZSBzdmdcbiAgICAgICAgICAgICAgICAgICAgZW1iZWQoaXRlbS5wYXJlbnQsIGl0ZW0uc3ZnLCB0YXJnZXQpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LCAvLyB0ZXN0IHRoZSByZWFkeSBzdGF0ZSBjaGFuZ2UgaW1tZWRpYXRlbHlcbiAgICAgICAgeGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSgpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBzdmc0ZXZlcnlib2R5KHJhd29wdHMpIHtcbiAgICAgICAgZnVuY3Rpb24gb25pbnRlcnZhbCgpIHtcbiAgICAgICAgICAgIC8vIHdoaWxlIHRoZSBpbmRleCBleGlzdHMgaW4gdGhlIGxpdmUgPHVzZT4gY29sbGVjdGlvblxuICAgICAgICAgICAgZm9yICgvLyBnZXQgdGhlIGNhY2hlZCA8dXNlPiBpbmRleFxuICAgICAgICAgICAgdmFyIGluZGV4ID0gMDsgaW5kZXggPCB1c2VzLmxlbmd0aDsgKSB7XG4gICAgICAgICAgICAgICAgLy8gZ2V0IHRoZSBjdXJyZW50IDx1c2U+XG4gICAgICAgICAgICAgICAgdmFyIHVzZSA9IHVzZXNbaW5kZXhdLCBwYXJlbnQgPSB1c2UucGFyZW50Tm9kZSwgc3ZnID0gZ2V0U1ZHQW5jZXN0b3IocGFyZW50KSwgc3JjID0gdXNlLmdldEF0dHJpYnV0ZShcInhsaW5rOmhyZWZcIikgfHwgdXNlLmdldEF0dHJpYnV0ZShcImhyZWZcIik7XG4gICAgICAgICAgICAgICAgaWYgKCFzcmMgJiYgb3B0cy5hdHRyaWJ1dGVOYW1lICYmIChzcmMgPSB1c2UuZ2V0QXR0cmlidXRlKG9wdHMuYXR0cmlidXRlTmFtZSkpLCBcbiAgICAgICAgICAgICAgICBzdmcgJiYgc3JjKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwb2x5ZmlsbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFvcHRzLnZhbGlkYXRlIHx8IG9wdHMudmFsaWRhdGUoc3JjLCBzdmcsIHVzZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyByZW1vdmUgdGhlIDx1c2U+IGVsZW1lbnRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJlbnQucmVtb3ZlQ2hpbGQodXNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBwYXJzZSB0aGUgc3JjIGFuZCBnZXQgdGhlIHVybCBhbmQgaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgc3JjU3BsaXQgPSBzcmMuc3BsaXQoXCIjXCIpLCB1cmwgPSBzcmNTcGxpdC5zaGlmdCgpLCBpZCA9IHNyY1NwbGl0LmpvaW4oXCIjXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGlmIHRoZSBsaW5rIGlzIGV4dGVybmFsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHVybC5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZ2V0IHRoZSBjYWNoZWQgeGhyIHJlcXVlc3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHhociA9IHJlcXVlc3RzW3VybF07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGVuc3VyZSB0aGUgeGhyIHJlcXVlc3QgZXhpc3RzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHhociB8fCAoeGhyID0gcmVxdWVzdHNbdXJsXSA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpLCB4aHIub3BlbihcIkdFVFwiLCB1cmwpLCB4aHIuc2VuZCgpLCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeGhyLl9lbWJlZHMgPSBbXSksIC8vIGFkZCB0aGUgc3ZnIGFuZCBpZCBhcyBhbiBpdGVtIHRvIHRoZSB4aHIgZW1iZWRzIGxpc3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeGhyLl9lbWJlZHMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJlbnQ6IHBhcmVudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN2Zzogc3ZnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGlkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pLCAvLyBwcmVwYXJlIHRoZSB4aHIgcmVhZHkgc3RhdGUgY2hhbmdlIGV2ZW50XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRyZWFkeXN0YXRlY2hhbmdlKHhocik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZW1iZWQgdGhlIGxvY2FsIGlkIGludG8gdGhlIHN2Z1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbWJlZChwYXJlbnQsIHN2ZywgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGluY3JlYXNlIHRoZSBpbmRleCB3aGVuIHRoZSBwcmV2aW91cyB2YWx1ZSB3YXMgbm90IFwidmFsaWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICsraW5kZXgsICsrbnVtYmVyT2ZTdmdVc2VFbGVtZW50c1RvQnlwYXNzO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gaW5jcmVhc2UgdGhlIGluZGV4IHdoZW4gdGhlIHByZXZpb3VzIHZhbHVlIHdhcyBub3QgXCJ2YWxpZFwiXG4gICAgICAgICAgICAgICAgICAgICsraW5kZXg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gY29udGludWUgdGhlIGludGVydmFsXG4gICAgICAgICAgICAoIXVzZXMubGVuZ3RoIHx8IHVzZXMubGVuZ3RoIC0gbnVtYmVyT2ZTdmdVc2VFbGVtZW50c1RvQnlwYXNzID4gMCkgJiYgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKG9uaW50ZXJ2YWwsIDY3KTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgcG9seWZpbGwsIG9wdHMgPSBPYmplY3QocmF3b3B0cyksIG5ld2VySUVVQSA9IC9cXGJUcmlkZW50XFwvWzU2N11cXGJ8XFxiTVNJRSAoPzo5fDEwKVxcLjBcXGIvLCB3ZWJraXRVQSA9IC9cXGJBcHBsZVdlYktpdFxcLyhcXGQrKVxcYi8sIG9sZGVyRWRnZVVBID0gL1xcYkVkZ2VcXC8xMlxcLihcXGQrKVxcYi8sIGVkZ2VVQSA9IC9cXGJFZGdlXFwvLihcXGQrKVxcYi8sIGluSWZyYW1lID0gd2luZG93LnRvcCAhPT0gd2luZG93LnNlbGY7XG4gICAgICAgIHBvbHlmaWxsID0gXCJwb2x5ZmlsbFwiIGluIG9wdHMgPyBvcHRzLnBvbHlmaWxsIDogbmV3ZXJJRVVBLnRlc3QobmF2aWdhdG9yLnVzZXJBZ2VudCkgfHwgKG5hdmlnYXRvci51c2VyQWdlbnQubWF0Y2gob2xkZXJFZGdlVUEpIHx8IFtdKVsxXSA8IDEwNTQ3IHx8IChuYXZpZ2F0b3IudXNlckFnZW50Lm1hdGNoKHdlYmtpdFVBKSB8fCBbXSlbMV0gPCA1MzcgfHwgZWRnZVVBLnRlc3QobmF2aWdhdG9yLnVzZXJBZ2VudCkgJiYgaW5JZnJhbWU7XG4gICAgICAgIC8vIGNyZWF0ZSB4aHIgcmVxdWVzdHMgb2JqZWN0XG4gICAgICAgIHZhciByZXF1ZXN0cyA9IHt9LCByZXF1ZXN0QW5pbWF0aW9uRnJhbWUgPSB3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lIHx8IHNldFRpbWVvdXQsIHVzZXMgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcInVzZVwiKSwgbnVtYmVyT2ZTdmdVc2VFbGVtZW50c1RvQnlwYXNzID0gMDtcbiAgICAgICAgLy8gY29uZGl0aW9uYWxseSBzdGFydCB0aGUgaW50ZXJ2YWwgaWYgdGhlIHBvbHlmaWxsIGlzIGFjdGl2ZVxuICAgICAgICBwb2x5ZmlsbCAmJiBvbmludGVydmFsKCk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldFNWR0FuY2VzdG9yKG5vZGUpIHtcbiAgICAgICAgZm9yICh2YXIgc3ZnID0gbm9kZTsgXCJzdmdcIiAhPT0gc3ZnLm5vZGVOYW1lLnRvTG93ZXJDYXNlKCkgJiYgKHN2ZyA9IHN2Zy5wYXJlbnROb2RlKTsgKSB7fVxuICAgICAgICByZXR1cm4gc3ZnO1xuICAgIH1cbiAgICByZXR1cm4gc3ZnNGV2ZXJ5Ym9keTtcbn0pOyJdLCJzb3VyY2VSb290IjoiIn0=