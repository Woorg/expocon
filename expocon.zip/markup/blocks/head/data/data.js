head: {
    defaults: {
        title: 'Main page',
    },
    // inner: {
    //     title: 'Inner page',
    //     useSocialMetaTags: false
    // },
    // university: {
    //     title: 'University page',
    //     useSocialMetaTags: false
    // }
}