<p align="right">
English description | <a href="../ru/fonts-and-misc.md">Описание на русском</a>
</p>

# Working with fonts and misc-files

All fonts are in the fonts folder with statics for the project.

In misc folder you can store any additional files, such as favicon and so on. All files will be copied from here into the root of the compiled project. Supports nested directories. When you copy files folder hierarchy will be saved.
